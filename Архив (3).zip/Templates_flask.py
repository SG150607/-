from flask import Flask, url_for, render_template

app = Flask(__name__)


@app.route('/training/<prof>')
def index(prof):
    return render_template('base2_0.html', css=url_for('static', filename='css/style.css'),
                           pic1=url_for('static', filename='img/place1.jpg'),
                           pic2=url_for('static', filename='img/place2.jpg'), prof=prof)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
